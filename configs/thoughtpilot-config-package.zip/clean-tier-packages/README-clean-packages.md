# Clean Tier Packages Manifest

**Generated**: 08/02/2025 00:11:40
**Timestamp**: 20250802_001140
**Purpose**: Production-ready application packages (DEV content excluded)

## Package Contents

### What's INCLUDED
- Application binaries and executables
- Configuration files (user-facing)
- Assets and resources
- Dependencies and libraries
- License files
- User documentation

### What's EXCLUDED
- DEV summaries and logs
- Patch files and development scripts
- Build artifacts and temporary files
- Debug symbols and development tools
- Internal documentation
- Test files and test data

## Package Locations

- **Free Tier**: /Users/sawyer/gitSync/thoughtpilot-commercial/clean-tier-packages/thoughtpilot-free/
- **Pro Tier**: /Users/sawyer/gitSync/thoughtpilot-commercial/clean-tier-packages/thoughtpilot-pro/
- **Team Tier**: /Users/sawyer/gitSync/thoughtpilot-commercial/clean-tier-packages/thoughtpilot-team/
- **Enterprise Tier**: /Users/sawyer/gitSync/thoughtpilot-commercial/clean-tier-packages/thoughtpilot-enterprise/

## Usage

These clean packages should be used for:
- Creating installer packages
- Distribution to end users
- Production deployments

**DO NOT** use these for development - use the original tier packages instead.
